//
//  product_swiftuiApp.swift
//  product_swiftui
//
//  Created by Putu Denisa Florence Satriani on 01/03/23.
//

import SwiftUI

@main
struct product_swiftuiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
